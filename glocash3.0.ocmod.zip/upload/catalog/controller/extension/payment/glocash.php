<?php
class ControllerExtensionPaymentGlocash extends Controller {
	protected $pm_id = '';
	public function index() {
		$logger = new Log('glocash.log');
		
		$data['button_confirm'] = $this->language->get('button_confirm');

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$logger->write('beforehand order created:'.json_encode($order_info));

		if (!$this->config->get('payment_glocash_test')) {
			$gatewayUrl= 'https://pay.glocash.com/gateway/payment/index';
		} else {
			$gatewayUrl= 'https://sandbox.glocash.com/gateway/payment/index';
		}
		
		
		$param= array(
				//付款请求参数
				'REQ_TIMES'=>time(),
				'REQ_EMAIL'=> $this->config->get('payment_glocash_email'),
				'REQ_INVOICE'=> $order_info['order_id'],
				'CUS_EMAIL'=>$order_info['email'],
				'BIL_PRICE'=>$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false),
				'BIL_CURRENCY'=>$order_info['currency_code'],
				'BIL_METHOD'=>'C01',
				//付款处理后，付款人的终端浏览器将跳转至对应的地址
				'URL_SUCCESS'=>$this->url->link('checkout/success', '', true),
				'URL_PENDING'=>$this->url->link('checkout/success', '', true),
				'URL_FAILED'=>$this->url->link('checkout/failure', '', true),
				'URL_NOTIFY'=>$this->url->link('extension/payment/glocash/notify', '', true),
				'BIL_GOODSNAME'=>'',// 展示在付款页面的商品描述
		);
		

		
		$param['REQ_SIGN'] = hash("sha256",
				$this->config->get('payment_glocash_secretkey').
				$param['REQ_TIMES'].
				$param['REQ_EMAIL'].
				$param['REQ_INVOICE'].
				$param['CUS_EMAIL'].
				$param['BIL_METHOD'].
				$param['BIL_PRICE'].
				$param['BIL_CURRENCY']
		);
		
		$this->Dblog($param['REQ_INVOICE'],'beforehand order get url param:'.json_encode($param));
		
		$httpCode = $this->paycurl($gatewayUrl, http_build_query($param), $result);
		$datas = json_decode($result, true);
		
		$logger->write('beforehand order payment url:'.$gatewayUrl.' method:post Request:'.json_encode($param).' Result:'.$result);
		
		$this->Dblog($param['REQ_INVOICE'],'beforehand order paycurl:'.json_encode($datas));
		
		$action="";
		if ($httpCode!=200 || empty($datas['URL_PAYMENT'])) {
			// 请求失败
			$action=$this->url->link('checkout/failure', '', true);
		}
		else{
			$action=$datas['URL_PAYMENT'];
		}
		
		//跳转到付款页
		$data['action'] = $action;
		$data['source'] = 'opencart';		
		
		//扔入页面表单提交
		$version_oc = substr(VERSION, 0, 3);
		$logger->write('oc version:'.$version_oc);
		if($version_oc == "2.3")
		{
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/glocash.twig')) {
				return $this->load->view($this->config->get('config_template') . '/template/extension/payment/glocash.twig', $data);
			} else {
				return $this->load->view('extension/payment/glocash', $data);
			}
		}
		else
		{
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/glocash')) {
				return $this->load->view($this->config->get('config_template') . '/template/extension/payment/glocash', $data);
			} else {
				return $this->load->view('default/template/extension/payment/glocash', $data);
			}
		}
	}	
	
	/**
	 * 支付curl提交
	 * @param $url
	 * @param $postData
	 * @param $result
	 * akirametero
	 */
	private function paycurl( $url, $postData, &$result ){
		$options = array();
		if (!empty($postData)) {
			$options[CURLOPT_CUSTOMREQUEST] = 'POST';
			$options[CURLOPT_POSTFIELDS] = $postData;
		}
		$options[CURLOPT_USERAGENT] = 'Glocash/v2.*/CURL';
		$options[CURLOPT_ENCODING] = 'gzip,deflate';
		$options[CURLOPT_HTTPHEADER] = [
		'Accept: text/html,application/xhtml+xml,application/xml',
		'Accept-Language: en-US,en',
		'Pragma: no-cache',
		'Cache-Control: no-cache'
				];
		$options[CURLOPT_RETURNTRANSFER] = 1;
		$options[CURLOPT_HEADER] = 0;
		if (substr($url,0,5)=='https') {
			$options[CURLOPT_SSL_VERIFYPEER] = false;
		}
		$ch = curl_init($url);
		curl_setopt_array($ch, $options);
		$result = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		return $httpCode;
	}

	public function notify() {
		
		$logger = new Log('glocash.log');
		$this->load->model('checkout/order');
		try {
						
			$valid = $this->validatePSNSIGN($this->request->post);
			$track_id =$this->request->post['REQ_INVOICE'];
			
			$order_info = $this->model_checkout_order->getOrder($track_id);
			if ($this->request->post['PGW_CURRENCY'] == $this->request->post['BIL_CURRENCY'] && $order_info["total"] != $this->request->post['PGW_PRICE']) {
				$comment = "order:".$order_info["order_id"]." grandTotal=".$order_info["total"]." , no equal to PGW_PRICE=:".$this->request->post['PGW_PRICE'];
				$logger->write($comment);
			}
			else{
				
				$this->Dblog($track_id,'notify:'.json_encode($this->request->post));
				
				if(!$valid){
					$commit=$this->language->get('text_pw_mismatch');
					if($commit=="text_pw_mismatch")
						$commit="Validate does not match. Order requires investigation.";
					
					$logger->write('Validation failed order_status_id:'.$this->config->get('config_order_status_id').' Result:'.json_encode($this->request->post));
					
					$this->model_checkout_order->addOrderHistory($track_id, $this->config->get('config_order_status_id'), $commit);
					$this->response->setOutput('verify failed');
				}
				else{
					$logger->write('notify Result:'.json_encode($this->request->post));
					
					$state = $this->request->post['BIL_STATUS'];
					$message = '';
						
					if (isset($this->request->post['BIL_STATUS'])) {
						$message .= 'BIL_STATUS: ' . $this->request->post['BIL_STATUS'] . "\n";
					}
					
					if (isset($this->request->post['REQ_INVOICE'])) {
						$message .= 'REQ_INVOICE: ' . $this->request->post['REQ_INVOICE'] . "\n";
					}
						
					if (isset($this->request->post['PGW_PRICE'])) {
						$message .= 'PGW_PRICE: ' . $this->request->post['BIL_PRICE'] . "\n";
					}
						
					if (isset($this->request->post['PGW_CURRENCY'])) {
						$message .= 'PGW_CURRENCY: ' . $this->request->post['BIL_CURRENCY'] . "\n";
					}
						
					if (isset($this->request->post['TNS_GCID'])) {
						$message .= 'TNS_GCID: ' . $this->request->post['TNS_GCID'] . "\n";
					}
						
					if (isset($this->request->post['REQ_SIGN'])) {
						$message .= 'REQ_SIGN: ' . $this->request->post['REQ_SIGN'] . "\n";
					}
						
					$status_list = array(
							'unpaid' => $this->config->get('payment_glocash_unpaid_status_id'),
							'paid' => $this->config->get('payment_glocash_paid_status_id'),
							'pending' => $this->config->get('payment_glocash_pending_status_id'),
							'cancelled' => $this->config->get('payment_glocash_cancelled_status_id'),
							'failed' => $this->config->get('payment_glocash_failed_status_id'),
							'refunding' => $this->config->get('payment_glocash_refunding_status_id'),
							'refunded' => $this->config->get('payment_glocash_refunded_status_id'),
							'complaint' => $this->config->get('payment_glocash_complaint_status_id'),
							'chargeback' => $this->config->get('payment_glocash_chargeback_status_id')
					);

					$logger->write('notify log orderid:'.$track_id.' status:'.$status_list[$state].' message:'.$message);
					$this->Dblog($track_id,'notify orderid:'.$track_id.' s:'.$status_list[$state].' m:'.$message);
					
					$this->model_checkout_order->addOrderHistory($track_id, $status_list[$state], $message);
					$this->response->setOutput('success');
				}
				
			}
			
			
			
		}catch (\Exception $e){
			$logger->write('notify Exception:'.$e->getMessage());
			$this->model_checkout_order->addOrderHistory($track_id, $this->config->get('config_order_status_id'), $this->language->get('text_pw_mismatch'));
			$this->response->setOutput('verify failed');
		}
		

	}
	
	
	// 验证 付款结果/PSN 提交的REQ_SIGN 是否合法
	public function validatePSNSIGN($param){
		// REQ_SIGN = SHA256 ( SECRET_KEY + REQ_TIMES + REQ_EMAIL + CUS_EMAIL + TNS_GCID + BIL_STATUS + BIL_METHOD + PGW_PRICE + PGW_CURRENCY )
		$sign = hash("sha256",
				$this->config->get('payment_glocash_secretkey').
				$param['REQ_TIMES'].
				$this->config->get('payment_glocash_email').
				$param['CUS_EMAIL'].
				$param['TNS_GCID'].
				$param['BIL_STATUS'].
				$param['BIL_METHOD'].
				$param['PGW_PRICE'].
				$param['PGW_CURRENCY']
		);
	
		return $sign==$param['REQ_SIGN'];
	}
	
	public function Dblog($orderId, $param)
	{
		try{
			$logger = new Log('glocash.log');
			if(is_string($param)){
				$message = $param;
			}else{
				$message = json_encode($param);
			}
				
			$this->db->query('
	            CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'glocash_log` (
				`id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
	            `id_order` varchar(50) NOT NULL,
	            `message` text NOT NULL,
	            `date_add` datetime NOT NULL,
	            PRIMARY KEY (`id_log`),
	            KEY `id_order` (`id_order`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8');
				
			$sql="insert into ".DB_PREFIX."glocash_log(id_order,message,date_add) values('".$orderId."','".$message."','".date("Y-m-d H:i:s", time())."') ";
	
			$this->db->query($sql);
		}
		catch (\exception $err){
			$logger->write('dblog error:'.$err->getMessage());
		}
	
	}
	
}